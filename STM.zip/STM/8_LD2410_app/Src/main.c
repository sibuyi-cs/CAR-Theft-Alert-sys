#include <ld2410_driver.h>
#include <stdio.h>
#include "stm32f4xx.h"
#include "fpu.h"
#include "timebase.h"
#include "bsp.h"
#include "adc.h"
#include "ld2410_lib.h"


/*Modules:
 * FPU
 * UART
 * TIMEBASE
 * GPIO (BSP)
 * ADC
 * */



#define  GPIOAEN		(1U<<0)
#define  PIN5			(1U<<5)
#define  LED_PIN		PIN5

#define PIN13		(1U<<6)
#define BTN_PIN		PIN13

int main()
{

	/*Enable clock access to GPIOA*/
	RCC->AHB1ENR |= GPIOAEN;

	/*Set PA5 to output mode*/
	GPIOA->MODER |= (1U<<10);
	GPIOA->MODER &=~(1U<<11);


	/*Set PA6 to output mode*/
	GPIOA->MODER &=~(1U<<12);
	GPIOA->MODER &=~(1U<<13);

    GPIOA->PUPDR &=~ (1U << 12);
    GPIOA->PUPDR |=  (1U << 13);

	uint32_t last_reading;

	/*Enable FPU*/
	fpu_enable();

	/*Initialize debug UART*/
	debug_uart_init();

	/*Initialize timebase*/
	timebase_init();


	/*Initiailzie ld2410*/
	system_init();

	while(1){
	  uint8_t state = (GPIOA->IDR & (1U << 6)) ? 1 : 0;
	  if(is_connected() && get_tick() - last_reading >1000)
	  {
	    last_reading =  get_tick();
	    if(state==1){
	      printf("system armed \n\r");
	      delay(2000);
	      if(get_presence_detected()){
	        printf("\n\r");
	        printf("Presence detected! \n\r");
	        if(get_stationary_target_detected()){
	          printf("Stationary target distance: %d\n\r", get_stationary_target_distance());
	        }
	        if(get_moving_target_detected()){
	          printf("Moving target distance: %d\n\r", get_moving_target_distance());
	          if(get_moving_target_distance()<=31){
	            /*Report every second*/
	            printf("Take a picture!\n\r");
	            //set GPIO pin HIGH
	            GPIOA->ODR |=LED_PIN;
	            delay(5000);

	          }else{
	            printf("Continue Detecting !\n\r");
	            //set GPIO pin LOW
	            GPIOA->ODR &=~LED_PIN;
	            delay(1000);
	          }
	        }
	      }else{
	    	  GPIOA->ODR &=~LED_PIN;
	    	  printf("No presence Detected \n\r");
	      }

	    }else{
	      printf("Not armed \n\r");
	      GPIOA->ODR &=~LED_PIN;
	      delay(2000);
	    }
	  }
	}//end whille

}//end main

