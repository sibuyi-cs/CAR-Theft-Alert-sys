#include <ld2410_driver.h>
#include <stdint.h>

#define GPIOAEN		(1U<<0)
#define UART2EN		(1U<<17)
#define UART1EN     (1u<<4)

#define DBG_UART_BAUDRATE		115200
#define LD2410_UART_BAUDRATE	256000
#define SYS_FREQ				16000000
#define APB1_CLK				SYS_FREQ
#define APB2_CLK				SYS_FREQ

#define CR1_TE					(1U<<3)
#define CR1_RE					(1U<<2)

#define CR1_UE					(1U<<13)
#define SR_TXE					(1U<<7)


static void uart_set_baudrate(uint32_t periph_clk,uint32_t baudrate);
static void uart_write(int ch);
uint16_t compute_uart_bd(uint32_t periph_clk,uint32_t baudrate);

int __io_putchar(int ch)
{
	uart_write(ch);
	return ch;
}

void debug_uart_init(void)
{
	/*Enable clock access to GPIOA*/
	RCC->AHB1ENR |= GPIOAEN;

	/*Set the mode of PA2 to alternate function mode*/
	GPIOA->MODER &=~(1U<<4);
	GPIOA->MODER |=(1U<<5);

	/*Set alternate function type to AF7(UART2_TX)*/
	GPIOA->AFR[0] |=(1U<<8);
	GPIOA->AFR[0] |=(1U<<9);
	GPIOA->AFR[0] |=(1U<<10);
	GPIOA->AFR[0] &=~(1U<<11);

	/*Enable clock access to UART2*/
     RCC->APB1ENR |=	UART2EN;

	/*Configure uart baudrate*/
     uart_set_baudrate(APB1_CLK,DBG_UART_BAUDRATE);

	/*Configure transfer direction*/
     USART2->CR1 = CR1_TE;

	/*Enable UART Module*/
     USART2->CR1 |= CR1_UE;
}

/*UART MODULE:  UART1
 *UART PINS   :  PA9 = TX, PA10 = RX
 *
 *LD2410 RX   ---- TX (PA9)
 *LD2410 TX   ---- RX (PA10)*/

void ld2410_uart_init(void)
{
	/*Enable clock access to GPIOA*/
	RCC->AHB1ENR |= GPIOAEN;

	/*Set the mode of PA9,PA10 to alternate function mode*/
	GPIOA->MODER &=~(1U<<18);
	GPIOA->MODER |=(1U<<19);

	GPIOA->MODER &=~(1U<<20);
	GPIOA->MODER |=(1U<<21);

	/*Set alternate function type to AF7(UART1_TX,RX)*/
	GPIOA->AFR[1] |=(1U<<4);
	GPIOA->AFR[1] |=(1U<<5);
	GPIOA->AFR[1] |=(1U<<6);
	GPIOA->AFR[1] &=~(1U<<7);


	GPIOA->AFR[1] |=(1U<<8);
	GPIOA->AFR[1] |=(1U<<9);
	GPIOA->AFR[1] |=(1U<<10);
	GPIOA->AFR[1] &=~(1U<<11);

	/*Enable clock access to UART2*/
     RCC->APB2ENR |=	UART1EN;

	/*Configure uart baudrate*/
     USART1->BRR = compute_uart_bd(APB2_CLK,LD2410_UART_BAUDRATE);

	/*Configure transfer direction*/
     USART1->CR1 = CR1_TE | CR1_RE;

	/*Enable UART Module*/
     USART1->CR1 |= CR1_UE;
}
static void uart_write(int ch)
{
	/*Make sure transmit data register is empty*/
	while(!(USART2->SR & SR_TXE)){}

	/*Write to transmit data register*/
	USART2->DR =(ch & 0xFF);
}

void ld2410_uart_write_char(int ch)
{
	/*Make sure transmit data register is empty*/
	while(!(USART1->SR & SR_TXE)){}

	/*Write to transmit data register*/
	USART1->DR =(ch & 0xFF);
}
 uint16_t compute_uart_bd(uint32_t periph_clk,uint32_t baudrate)
{
	return((periph_clk + (baudrate/2U))/baudrate);
}

static void uart_set_baudrate(uint32_t periph_clk,uint32_t baudrate)
{
	USART2->BRR = compute_uart_bd(periph_clk,baudrate);
}
