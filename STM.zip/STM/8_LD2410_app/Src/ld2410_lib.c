#include "ld2410_lib.h"


#define LD2410_MAX_PACKET_LENGTH   45

// Define timeout for UART operations in milliseconds
uint32_t UART_TIMEOUT = 100;

uint32_t ld2410_last_packet = 0;

// Buffer to store incoming packets from radar
uint8_t ld2410_packet[LD2410_MAX_PACKET_LENGTH];

// Current position in the buffer
uint8_t packet_position = 0;

bool packet_started = false;

// Target detection variables
uint8_t target_type = 0;
uint16_t moving_target_dist = 0;
uint8_t moving_target_energy = 0;
uint8_t stationary_target_energy = 0;
uint16_t stationary_target_dist = 0;
uint16_t detection_distance = 0;

// Forward declarations of functions for parsing and printing
bool parse_data_frame();
void print_frame();


// USART status register flags
#define USART_FLAG_RXNE    (1U << 5)   // Receiver not empty flag

// PACKET markers for packet identification
#define PACKET_START_MARKER_1 0xF4
#define PACKET_START_MARKER_2 0xF3
#define PACKET_START_MARKER_3 0xF2
#define PACKET_START_MARKER_4 0xF1

#define PACKET_END_MARKER_1   0xF5
#define PACKET_END_MARKER_2   0xF6
#define PACKET_END_MARKER_3   0xF7
#define PACKET_END_MARKER_4   0xF8

// Frame validation specifics
#define PACKET_VALIDATION_LENGTH 	20
#define MAX_PACKET_LENGTH 			LD2410_MAX_PACKET_LENGTH

// Timeouts and intervals
#define CONNECTION_TIMEOUT UART_TIMEOUT

// Macro for checking a specific USART flag
#define USART_HAS_FLAG(USARTx, FLAG) ((USARTx->SR & (FLAG)) != 0)


// Target type flags
#define TARGET_TYPE_NONE       				0x00
#define TARGET_TYPE_MOVING     				0x01
#define TARGET_TYPE_STATIONARY 				0x02
#define TARGET_TYPE_MOVING_STATIONARY       0x03

#define REST_OF_BYTES       10

// Target detection thresholds
#define ENERG_DETECTION_THRESHOLD 0  // Minimum valid energy
#define DIST_DETECTION_THRESHOLD 0  // Minimum valid detection distance



#define NORMAL_PACKET_DATA_LENGTH   13
#define MODE_BYTE1_IDX     			6
#define MODE_BYTE2_IDX     			7
#define NORMAL_MODE_BYTE1_VAL    	0x02
#define NORMAL_MODE_BYTE2_VAL    	0xAA
#define MODE_TERM_BYTE1_IDX        	17  /*Mode terminator byte1*/
#define MODE_TERM_BYTE2_IDX        	18
#define MODE_TERM_BYTE1_VAL		  	0x55
#define MODE_TERM_BYTE2_VAL       	0x00



//#define LD2410_PRINT_DEBUG_INFO

// Utility macros for packet data extraction
#define GET_UINT16_FROM_PACKET(index) \
    (ld2410_packet[index] + (ld2410_packet[(index) + 1] << 8))


bool parse_data_frame(void);

void system_init(void)
{
	ld2410_uart_init();

	debug_uart_init();

#ifdef LD2410_PRINT_DEBUG_INFO

     printf("LD2410 Initialization complete...\n\r");
#endif
}


bool get_frame(void)
{
    // Check if data is available in the receiver buffer.
    if (!USART_HAS_FLAG(USART1, USART_FLAG_RXNE))
    {
        return false;
    }

    uint8_t new_byte = USART1->DR;

    if (!packet_started)
    {
        if (new_byte == PACKET_START_MARKER_1 || new_byte == PACKET_START_MARKER_2)
        {
            ld2410_packet[packet_position++] = new_byte;
            packet_started = true;
            return false;
        }
        return false;
    }

    if (packet_position < MAX_PACKET_LENGTH)
    {
        ld2410_packet[packet_position++] = new_byte;

        if (packet_position > PACKET_VALIDATION_LENGTH)
        {
            if (ld2410_packet[0] == PACKET_START_MARKER_1 &&
                ld2410_packet[packet_position - 4] == PACKET_END_MARKER_4 &&
                ld2410_packet[packet_position - 3] == PACKET_END_MARKER_3 &&
                ld2410_packet[packet_position - 2] == PACKET_END_MARKER_2 &&
                ld2410_packet[packet_position - 1] == PACKET_END_MARKER_1)
            {
                if (parse_data_frame())
                {
                    packet_started = false;
                    packet_position = 0;
                    return true;
                }
                packet_started = false;
                packet_position = 0;
            }
        }
    }
    else
    {
        packet_started = false;
        packet_position = 0;
    }
    return false;
}


bool parse_data_frame(void)
{

    // Calculate packet data length from the header
    uint16_t packet_data_len = ld2410_packet[4] + (ld2410_packet[5] << 8);

    // Ensure the entire packet has been received.
    if (packet_position == packet_data_len + REST_OF_BYTES)
    {
        // Optionally print the received packet for debugging.
        print_frame();

        // Validate and process basic  data frame.
        if (packet_data_len == NORMAL_PACKET_DATA_LENGTH &&
            ld2410_packet[MODE_BYTE1_IDX] == NORMAL_MODE_BYTE1_VAL &&
            ld2410_packet[MODE_BYTE2_IDX] == NORMAL_MODE_BYTE2_VAL &&
            ld2410_packet[MODE_TERM_BYTE1_IDX] == MODE_TERM_BYTE1_VAL &&
            ld2410_packet[MODE_TERM_BYTE2_IDX] == MODE_TERM_BYTE2_VAL)
        {
            // Extract and store target information.
            target_type = ld2410_packet[8];
            moving_target_dist = GET_UINT16_FROM_PACKET(9);
            moving_target_energy = ld2410_packet[11];
            stationary_target_dist = GET_UINT16_FROM_PACKET(12);
            stationary_target_energy = ld2410_packet[14];
            detection_distance = GET_UINT16_FROM_PACKET(15);

#ifdef LD2410_PRINT_DEBUG_INFO
            printf("\n\r************* NORMAL DATA FRAME **************\n\r");
            switch (target_type)
            {
                case TARGET_TYPE_NONE:
                    printf("NO TARGET\n\r");
                    break;
                case TARGET_TYPE_MOVING:
                    printf("MOVING TARGET\n\r");
                    break;
                case TARGET_TYPE_STATIONARY:
                    printf("STATIONARY TARGET\n\r");
                    break;
                case TARGET_TYPE_MOVING_STATIONARY:
                    printf("MOVING & STATIONARY TARGETS\n\r");
                    break;
            }

            if (target_type & TARGET_TYPE_MOVING)
            {
                printf("Distance to moving object in CM: %d\n\r", moving_target_dist);
                printf("Energy of moving object: %d\n\r", moving_target_energy);
            }
            if (target_type & TARGET_TYPE_STATIONARY)
            {
                printf("Distance to stationary object in CM: %d\n\r", stationary_target_dist);
                printf("Energy of stationary object: %d\n\r", stationary_target_energy);
            }
            printf("Detection distance in CM: %d\n\r", detection_distance);
#endif
            // Update the timestamp for the last packet received.
            ld2410_last_packet = get_tick();
            return true;
        }
    }

    return false; // Frame is not valid or complete.
}


void print_frame(void)
{
#ifdef  LD2410_PRINT_DEBUG_INFO

	printf("\nData: ");
	for(uint8_t i = 0; i < packet_position; i++)
	{
		if(ld2410_packet[i] < 0x10)
		{
			printf("0");
		}
		printf("%x",ld2410_packet[i]);
	}

	printf("\n");
#endif
}


bool is_connected(void)
{
	return get_frame();

}


bool get_presence_detected(void)
{
	return target_type != TARGET_TYPE_NONE;
}

bool get_stationary_target_detected(void)
{
	return (target_type & TARGET_TYPE_STATIONARY) && stationary_target_dist > DIST_DETECTION_THRESHOLD && stationary_target_energy > ENERG_DETECTION_THRESHOLD;
}


uint16_t get_stationary_target_distance(void)
{
	return stationary_target_dist;
}



bool get_moving_target_detected(void)
{
	return (target_type & TARGET_TYPE_MOVING) && moving_target_dist > DIST_DETECTION_THRESHOLD && moving_target_energy > ENERG_DETECTION_THRESHOLD;
}


uint16_t get_moving_target_distance(void)
{
	return moving_target_dist;
}

uint8_t get_moving_target_energy(void)
{
	return moving_target_energy;
}

uint8_t get_stationary_target_energy(void)
{
	return stationary_target_energy;
}

