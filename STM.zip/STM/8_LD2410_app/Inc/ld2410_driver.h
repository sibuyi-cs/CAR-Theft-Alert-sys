#ifndef __LD2410_DRIVER_H__
#define __LD2410_DRIVER_H__

#include "stm32f4xx.h"

void debug_uart_init(void);
void ld2410_uart_write_char(int ch);
void ld2410_uart_init(void);

#endif
