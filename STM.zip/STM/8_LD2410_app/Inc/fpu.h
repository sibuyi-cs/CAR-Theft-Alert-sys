#ifndef __FPU_H__
#define __FPU_H__

void fpu_enable(void);

#endif
