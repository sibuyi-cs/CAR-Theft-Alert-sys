#ifndef __LD2410_LIB_H__
#define __LD2410_LIB_H__

#include "ld2410_driver.h"
#include "timebase.h"
#include <stdbool.h>
#include <stdio.h>


uint8_t get_stationary_target_energy(void);
uint8_t get_moving_target_energy(void);
uint16_t get_moving_target_distance(void);
bool get_moving_target_detected(void);
uint16_t get_stationary_target_distance(void);
bool get_stationary_target_detected(void);
bool get_presence_detected(void);
bool is_connected(void);
bool get_frame(void);
void system_init(void);

#endif
